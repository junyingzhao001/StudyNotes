// coverage-plugin/build.gradle.kts
plugins {
    `kotlin-dsl`
    `java-gradle-plugin`   // ← 独立插件必须加这个
    `maven-publish`         // ← 用于发布到 Maven 仓库
}

group = "com.ninebot.tools"
version = "1.0.6"

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation("com.android.tools.build:gradle:8.6.0")
    implementation("org.ow2.asm:asm:9.6")
    implementation("org.ow2.asm:asm-commons:9.6")
    implementation("com.github.javaparser:javaparser-symbol-solver-core:3.25.8")
    implementation("org.jacoco:org.jacoco.core:0.8.11")
    implementation("org.jacoco:org.jacoco.report:0.8.11")
}

// ===== 插件元数据注册（替代 META-INF/gradle-plugins/*.properties） =====
gradlePlugin {
    plugins {
        create("incrementalCoverage") {
            id = "com.ninebot.coverage"                                    // 插件 ID
            implementationClass = "com.ninebot.coverage.IncrementalCoveragePlugin"  // 入口类
            displayName = "Incremental Coverage Plugin"
            description = "只对 Git 变更代码进行 JaCoCo 插桩和覆盖率统计"
        }
    }
}

// ===== 发布配置 =====
publishing {
    repositories {
        //  ./gradlew publishToMavenLocal  发布命令
        // 方式一：发布到本地目录（开发调试用）
//        maven {
//            name = "local"
//            url = uri("${rootProject.projectDir}/repo")
//        }

//         方式二：发布到公司内部 Maven（正式使用） ./gradlew publishPluginMavenPublicationToInternalRepository
         maven {
             isAllowInsecureProtocol = true
             name = "internal"
             // 测试
//             url = uri("http://nexus-ops.willand.com/repository/maven-snapshots")
             //             正式
             url = uri("http://nexus-ops.willand.com/repository/maven-releases")
             credentials {
                 username = "admin"
                 password = "ninebot@admin2025"
             }
         }
    }
}
