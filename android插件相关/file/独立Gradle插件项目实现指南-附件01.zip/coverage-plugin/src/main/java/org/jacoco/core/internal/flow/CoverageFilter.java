package org.jacoco.core.internal.flow;

import java.io.File;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 增量覆盖率过滤器。
 *
 * 【核心职责】：
 * 1. 它是连接 “Git Diff 变更分析” 与 “字节码插桩/报告分析” 的纽带。
 * 2. 运行时（或者在 Gradle 的类加载上下文中），`ClassProbesAdapter.visitMethod` 每次扫描到一个方法时，
 *    都会将类名、方法名和方法描述符传给 `isMethodChanged` 进行判定。
 * 3. 实现了高度精准的 Kotlin / Java 编译器合成方法（Synthetic Methods）及匿名内部类匹配算法。
 *
 * 【JSON 数据源格式】：
 *   文件路径由系统属性 `jacoco.incremental.json` 配置，典型结构如下：
 *   {
 *     "has_inline": false,
 *     "methods": [
 *       "MainActivity:onCreate",
 *       "RouteBuilder:withString"
 *     ]
 *   }
 */
public class CoverageFilter {
    // 缓存已解析的变更方法签名集合，避免在每次访问 visitMethod 时重复读写 IO 影响构建性能。
    private static Set<String> changedMethods = null;
    
    // 标记本分支是否改动了任何 Kotlin inline 函数。
    private static boolean hasInlineFallback = false;

    /**
     * 【极其关键的生命周期清理函数】：
     * - Gradle 进程默认使用 Daemon 守护进程模式在后台常驻，在多次编译/多次任务运行期间共享 JVM 状态。
     * - 如果我们不在插桩任务启动时清理这个静态字段，`changedMethods` 会一直保持第一次加载的数据。
     * - 我们在 `InstrumentCoverageTask` 开始时显式调用此方法重置缓存，确保最新一次 Git Diff 变更配置能被正确载入。
     */
    public static synchronized void resetCache() {
        changedMethods = null;
        hasInlineFallback = false;
    }

    /**
     * 判断指定类中的指定方法是否在本次增量变更范围内。
     *
     * 支持匹配的场景：
     * 1. 精确匹配：例如 `MainActivity` 类中的 `onCreate` 方法。
     * 2. Kotlin 协程/Lambda 合成方法匹配：Kotlin 编译器会将 lambda 编译为名为 `<methodName>$lambda$0` 的内部合成方法。
     *    例如 `MainActivity:onCreate` 被修改了，其下的合成方法 `onCreate$lambda$0` 也必须判定为已变更。
     * 3. Java Lambda 合成方法匹配：Java 编译器生成形如 `lambda$<methodName>$0` 的合成方法。
     *    例如 `MainActivity:onCreate` 改动，则 `lambda$onCreate$0` 同样必须命中。
     * 4. Kotlin 内部类 Lambda 匹配：Kotlin 会把复杂的 Lambda/局部函数编入类似于 `MainActivity$onCreate$1` 的独立匿名类中。
     *    本方法支持模糊识别以 `targetClass + "$" + targetMethod + "$"` 开头的匿名内部类，将其智能收录。
     *
     * @param className  JVM 内部类名，斜杠分隔，如 `com/segway/mower/MainActivity`
     * @param methodName 访问到的 JVM 方法名，如 `onCreate`、`<init>` 或合成的方法名
     * @param methodDesc 方法签名描述符，例如 `(Landroid/os/Bundle;)V` (当前保留，用作扩展支持同名重载)
     * @return true = 需要插桩 / 纳入覆盖率报告
     */
    public static synchronized boolean isMethodChanged(String className, String methodName, String methodDesc) {
        // 第一次匹配时，延迟加载 JSON 配置
        if (changedMethods == null) {
            loadChangedMethods();
        }
        
        // 如果改动了带有 inline 关键字的 Kotlin 方法，主动触发全量降级，以防止 SMAP 反向映射错误
        if (hasInlineFallback) {
            return true;
        }

        // 如果配置集加载为空（或文件不存在），则自动回退到全量覆盖率模式，保证功能可用
        if (changedMethods.isEmpty()) {
            return true;
        }

        // 将 JVM 风格的类名 com/segway/mower/MainActivity 转化为简短类名 MainActivity，
        // 注意保留嵌套内部类符号，如 MainActivity$Inner。
        String classFileOnly = className;
        int lastSlash = classFileOnly.lastIndexOf('/');
        if (lastSlash >= 0) {
            classFileOnly = classFileOnly.substring(lastSlash + 1);
        }

        // 匹配循环：遍历所有发生过修改的方法签名（格式为 ClassName:methodName）
        for (String entry : changedMethods) {
            int colonIdx = entry.indexOf(':');
            if (colonIdx < 0) continue; // 忽略格式不对的行

            String targetClass = entry.substring(0, colonIdx);
            String targetMethod = entry.substring(colonIdx + 1);

            // 检查当前访问的类是否与变更目标类一致（支持匹配内部类如 MainActivity$1）
            boolean classMatches = classFileOnly.equals(targetClass);
            
            if (classMatches) {
                // 场景 1：标准方法名精确一致匹配 (例如 targetMethod = "onCreate"，methodName = "onCreate")
                if (methodName.equals(targetMethod)) {
                    System.out.println("[IncrementalCoverage] ++ " + className + "." + methodName);
                    return true;
                }
                
                // 场景 2：Kotlin 匿名/合成 Lambda 函数匹配 (形如 targetMethod$lambda$X)
                if (methodName.startsWith(targetMethod + "$")) {
                    System.out.println("[IncrementalCoverage] ++ (Synthetic) " + className + "." + methodName);
                    return true;
                }
                
                // 场景 3：Java 匿名 Lambda 表达式匹配 (形如 lambda$targetMethod$X)
                if (methodName.startsWith("lambda$" + targetMethod + "$")) {
                    System.out.println("[IncrementalCoverage] ++ (JavaLambda) " + className + "." + methodName);
                    return true;
                }
            }

            // 场景 4：Kotlin 编译后为 Lambda 生成的独立匿名内部类匹配 (形如 MainActivity$onCreate$1)
            // 这种情况下，字节码中对应的类名 classFileOnly 会变成 MainActivity$onCreate$1，
            // 它是 targetClass (MainActivity) 与 targetMethod (onCreate) 的组合嵌套形式。
            // 这里我们采用前缀进行安全收割，限制匹配范围在 `targetClass$targetMethod$` 之后，避免误伤其他方法下的匿名内部类。
            if (classFileOnly.startsWith(targetClass + "$" + targetMethod + "$")) {
                System.out.println("[IncrementalCoverage] ++ (NamedInner) " + className + "." + methodName);
                return true;
            }
        }

        return false;
    }

    /**
     * 从配置文件中加载变更方法信息。
     *
     * 细节设计：
     * - 由于 buildSrc 插件处于轻量级的编译环境，为避免引入诸如 Gson、Jackson 等大体积第三方解析库，
     *   我们直接采用 Java 原生正则提取机制从文本中圈定双引号内的所有值。
     * - 系统属性 `jacoco.incremental.json` 是在任务配置期注入的。如果未配置，默认回退到 `build/outputs/coverage/changed_methods.json`。
     */
    private static void loadChangedMethods() {
        changedMethods = new HashSet<>();
        try {
            String path = System.getProperty("jacoco.incremental.json");
            if (path == null) {
                path = "build/outputs/coverage/changed_methods.json";
            }
            File f = new File(path);
            if (f.exists()) {
                String content = new String(Files.readAllBytes(f.toPath()));
                
                // 识别 inline Fallback 标记并开启降级
                if (content.contains("\"has_inline\": true") || content.contains("\"has_inline\":true")) {
                    hasInlineFallback = true;
                    System.out.println("[IncrementalCoverage] Fallback mode activated due to inline function modifications.");
                }
                
                // 使用正则匹配提取双引号内的内容作为签名值
                Matcher m = Pattern.compile("\"([^\"]+)\"").matcher(content);
                while (m.find()) {
                    String val_ = m.group(1);
                    // 跳过 JSON 原有的特定关键字定义
                    if ("methods".equals(val_) || "has_inline".equals(val_)) continue;
                    changedMethods.add(val_);
                }
                System.out.println("[IncrementalCoverage] Loaded " + changedMethods.size() + " changed methods from " + path);
            } else {
                System.out.println("[IncrementalCoverage] No changed_methods.json found at " + path + ", falling back to full mode");
            }
        } catch (Exception e) {
            System.err.println("[IncrementalCoverage] Error loading changed methods:");
            e.printStackTrace();
        }
    }
}
