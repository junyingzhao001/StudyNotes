/*******************************************************************************
 * Copyright (c) 2009, 2026 Mountainminds GmbH & Co. KG and Contributors
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *    Marc R. Hoffmann - initial API and implementation
 *
 *******************************************************************************/
package org.jacoco.core.internal.flow;

import org.jacoco.core.internal.instr.InstrSupport;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.commons.AnalyzerAdapter;

/**
 * 增量探针适配器。
 *
 * 【重写目的与技术设计】：
 * 1. 包劫持：此文件位于 `org.jacoco.core.internal.flow` 包下，同样通过类加载器优先级劫持了 JaCoCo 原生的 `ClassProbesAdapter`。
 * 2. 方法级增量拦截：在 `visitMethod` 编译周期方法中引入 `CoverageFilter.isMethodChanged`。
 *    - 判定为已变更的方法：照常植入探针，计算探针 ID，统计行覆盖率。
 *    - 判定为未变更的方法：
 *      - 【插桩阶段 (Offline Instrumentation)】：我们需要将该方法不经插桩修改地写入最终的输出 JAR 中。
 *        为此，我们通过 `cv.getDelegate().visitMethod` 绕过 ClassInstrumenter（插桩器），将 unmodified（未插桩）的原始方法字节码直接写入底层的 ClassWriter。
 *      - 【报告生成阶段 (Analyzer)】：由于此阶段我们不需要再分析未改动方法的覆盖数据，直接返回 `null`。
 *        ASM 链接收到 `null` 后会完全忽略该方法，在渲染的网页报告中该方法就不会出现（或者不参与红绿行统计），从而实现真正的增量覆盖率统计。
 */
public class ClassProbesAdapter extends ClassVisitor
		implements IProbeIdGenerator {

	private static final MethodProbesVisitor EMPTY_METHOD_PROBES_VISITOR = new MethodProbesVisitor() {
	};

	private final ClassProbesVisitor cv;

	private final boolean trackFrames;

	private int counter = 0;

	private String name;

	/**
	 * 创建一个新的 ClassProbesAdapter，代理给给定的 ClassProbesVisitor。
	 *
	 * @param cv
	 *            被代理的 Visitor
	 * @param trackFrames
	 *            如果为 true，则跟踪并提供 StackMap 帧
	 */
	public ClassProbesAdapter(final ClassProbesVisitor cv,
			final boolean trackFrames) {
		super(InstrSupport.ASM_API_VERSION, cv);
		this.cv = cv;
		this.trackFrames = trackFrames;
	}

	@Override
	public void visit(final int version, final int access, final String name,
			final String signature, final String superName,
			final String[] interfaces) {
		this.name = name;
		super.visit(version, access, name, signature, superName, interfaces);
	}

	@Override
	public final MethodVisitor visitMethod(final int access, final String name,
			final String desc, final String signature,
			final String[] exceptions) {
		
		// ==================== 增量方法过滤拦截 (INCREMENTAL FILTERING) ====================
		if (!CoverageFilter.isMethodChanged(this.name, name, desc)) {
			
			// 场景一：AGP 8 离线插桩打包阶段
			// `cv` 的实际实例是 `ClassInstrumenter`（插桩访问者）。
			// 为了防止未修改的方法被注入覆盖率变量和探针，我们不能走 `cv.visitMethod`（这会导致它被插桩）。
			// 但我们仍然需要把这个方法的原始字节码写回最终生成的 class/jar 中。
			// 幸好 ClassInstrumenter 继承自 ClassVisitor，其底层的 delegate 是 ClassWriter。
			// 因此，我们直接调用 `cv.getDelegate().visitMethod`，相当于“绕道/越狱”，将原封不动的方法字节码直接流向 ClassWriter 回写，完美透传未修改的方法！
			if (cv != null && cv.getDelegate() != null) {
				return cv.getDelegate().visitMethod(access, name, desc, signature, exceptions);
			}
			
			// 场景二：JaCoCo Analyzer 覆盖率分析报告阶段
			// 此时 `cv` 是 ClassAnalyzer，它并不包含底层 delegate。
			// 遇到不需要进行覆盖率计算的未改动方法，我们直接返回 `null`。
			// 这会指引 ASM 架构完全跳过该方法的节点分析，不计算它的探针覆盖情况，避免已存在的未覆盖行将我们的增量指标拉低。
			return null;
		}

		// ==================== 改动方法：正常解析并生成覆盖率探针 ====================
		final MethodProbesVisitor methodProbes;
		final MethodProbesVisitor mv = cv.visitMethod(access, name, desc,
				signature, exceptions);
		if (mv == null) {
			// 如果 mv 为空，我们仍需要走一遍虚拟的 MethodVisitor 以便分配探针 ID，
			// 确保探针 ID 的计算和分配机制是稳定、可复现（Reproducible）的。
			methodProbes = EMPTY_METHOD_PROBES_VISITOR;
		} else {
			methodProbes = mv;
		}
		
		// 结合 MethodSanitizer 重建控制流图并根据需要标记标签（Labels），最后为每一条指令流分支织入探针 ID。
		return new MethodSanitizer(null, access, name, desc, signature,
				exceptions) {

			@Override
			public void visitEnd() {
				super.visitEnd();
				LabelFlowAnalyzer.markLabels(this);
				final MethodProbesAdapter probesAdapter = new MethodProbesAdapter(
						methodProbes, ClassProbesAdapter.this);
				if (trackFrames) {
					final AnalyzerAdapter analyzer = new AnalyzerAdapter(
							ClassProbesAdapter.this.name, access, name, desc,
							probesAdapter);
					probesAdapter.setAnalyzer(analyzer);
					methodProbes.accept(this, analyzer);
				} else {
					methodProbes.accept(this, probesAdapter);
				}
			}
		};
	}

	@Override
	public void visitEnd() {
		// 汇总并通知当前的类一共分配了多少个探针
		cv.visitTotalProbeCount(counter);
		super.visitEnd();
	}

	// === IProbeIdGenerator 接口实现：顺序分配全局探针 ID ===

	public int nextId() {
		return counter++;
	}

}
