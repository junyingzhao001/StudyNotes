/*******************************************************************************
 * Copyright (c) 2009, 2026 Mountainminds GmbH & Co. KG and Contributors
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *    Marc R. Hoffmann - initial API and implementation
 *
 *******************************************************************************/
package org.jacoco.core.analysis;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.jacoco.core.JaCoCo;
import org.jacoco.core.data.ExecutionData;
import org.jacoco.core.data.ExecutionDataStore;
import org.jacoco.core.internal.ContentTypeDetector;
import org.jacoco.core.internal.InputStreams;
import org.jacoco.core.internal.Pack200Streams;
import org.jacoco.core.internal.analysis.ClassAnalyzer;
import org.jacoco.core.internal.analysis.ClassCoverageImpl;
import org.jacoco.core.internal.analysis.StringPool;
import org.jacoco.core.internal.data.CRC64;
import org.jacoco.core.internal.flow.ClassProbesAdapter;
import org.jacoco.core.internal.instr.InstrSupport;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;

/**
 * 增量覆盖率报告分析器。
 *
 * 【非常核心的技术设计 — Java 类覆盖/包劫持 (Class Shadowing & Package Hijacking)】：
 * 1. 为什么我们要把 JaCoCo 官方的 `Analyzer.java` 源码复制并重写到 buildSrc 目录中？
 *    - 在 Gradle 构建中，`buildSrc` 下编译出的类拥有比 build.gradle 依赖中引入的第三方 JAR 更高的类加载优先级（Classloader Priority）。
 *    - 当 Gradle 运行覆盖率报告渲染任务时，JVM Classloader 会优先加载此 `org.jacoco.core.analysis.Analyzer`，
 *      而不是 JaCoCo 官方依赖包里的同一个类。
 * 2. 劫持后做了什么？
 *    - 我们将原本的 Class 分析流程与自定义的 `ClassProbesAdapter` 进行绑定（详见本类 `createAnalyzingVisitor` 方法）。
 *    - 这一步确保在分析 `.ec` 执行数据和渲染 HTML 页面时，数据流能够自动走入我们的 `CoverageFilter` 过滤器。
 *    - 过滤器会丢弃所有没有发生变更的方法数据，使得未变更的方法完全不参与探针命中的逻辑核对。
 *    - 从而完美解决了“未改动的方法在报告中因探针未执行而显示为红色，污染增量覆盖率”的业界难题。
 */
public class Analyzer {

	private final ExecutionDataStore executionData;

	private final ICoverageVisitor coverageVisitor;

	private final StringPool stringPool;

	/**
	 * 创建一个将覆盖率分析结果上报给 ICoverageVisitor 的分析器。
	 *
	 * @param executionData
	 *            运行时的探针数据存储库
	 * @param coverageVisitor
	 *            输出分析结果的访问器实例
	 */
	public Analyzer(final ExecutionDataStore executionData,
			final ICoverageVisitor coverageVisitor) {
		this.executionData = executionData;
		this.coverageVisitor = coverageVisitor;
		this.stringPool = new StringPool();
	}

	/**
	 * 创建用于覆盖率分析的 ASM 类访问器（ClassVisitor）。
	 *
	 * 【关键改动点】：
	 * 拦截并返回我们自己 buildSrc 下自定义重写的 `ClassProbesAdapter` 实例。
	 * 这样一来，在 Class 结构扫描期间，每当遍历到一个方法，都会自动进入我们的 `CoverageFilter.isMethodChanged` 增量判定。
	 * 未变动的方法将不会被分析（直接返回空 Visitor 丢弃），极大地加快了 HTML 报告渲染时间，
	 * 且不会将未改动的方法计入报告的覆盖百分比统计。
	 *
	 * @param classid
	 *            当前类的 CRC64 唯一 ID
	 * @param className
	 *            类在 JVM 中的路径名 (例如 com/segway/mower/MainActivity)
	 * @return 绑定了分析逻辑的 ASM ClassVisitor
	 */
	private ClassVisitor createAnalyzingVisitor(final long classid,
			final String className) {
		final ExecutionData data = executionData.get(classid);
		final boolean[] probes;
		final boolean noMatch;
		if (data == null) {
			probes = null;
			noMatch = executionData.contains(className);
		} else {
			probes = data.getProbes();
			noMatch = false;
		}
		final ClassCoverageImpl coverage = new ClassCoverageImpl(className,
				classid, noMatch);
		final ClassAnalyzer analyzer = new ClassAnalyzer(coverage, probes,
				stringPool) {
			@Override
			public void visitEnd() {
				super.visitEnd();
				coverageVisitor.visitCoverage(coverage);
			}
		};
		// 返回我们自定义的 ClassProbesAdapter 以注入 CoverageFilter 过滤逻辑
		return new ClassProbesAdapter(analyzer, false);
	}

	/**
	 * 分析单个 Class 的字节码 buffer 并提取其覆盖数据。
	 */
	private void analyzeClass(final byte[] source) {
		final long classId = CRC64.classId(source);
		final ClassReader reader = InstrSupport.classReaderFor(source);
		if ((reader.getAccess() & Opcodes.ACC_MODULE) != 0) {
			return;
		}
		if (reader.getClassName().endsWith("/package-info")) {
			return;
		}
		final ClassVisitor visitor = createAnalyzingVisitor(classId,
				reader.getClassName());
		reader.accept(visitor, 0);
	}

	/**
	 * 从内存缓冲（Byte Array）分析指定的类。
	 *
	 * @param buffer
	 *            类的字节码缓冲
	 * @param location
	 *            报错信息中指示的位置标签
	 * @throws IOException
	 *             如果解析遇到异常
	 */
	public void analyzeClass(final byte[] buffer, final String location)
			throws IOException {
		try {
			analyzeClass(buffer);
		} catch (final RuntimeException cause) {
			throw analyzerError(location, cause);
		}
	}

	/**
	 * 从输入流中读取字节码并分析类。本方法不会自动关闭输入流。
	 */
	public void analyzeClass(final InputStream input, final String location)
			throws IOException {
		final byte[] buffer;
		try {
			buffer = InputStreams.readFully(input);
		} catch (final IOException e) {
			throw analyzerError(location, e);
		}
		analyzeClass(buffer, location);
	}

	private IOException analyzerError(final String location,
			final Exception cause) {
		final IOException ex = new IOException(
				String.format("Error while analyzing %s with JaCoCo %s/%s.",
						location, JaCoCo.VERSION, JaCoCo.COMMITID_SHORT));
		ex.initCause(cause);
		return ex;
	}

	/**
	 * 从给定的输入流分析其中包含的所有 Class。
	 * 流可以是一个单独的 .class 文件，也可以是 ZIP、GZIP、Pack200 压缩包。
	 * 本方法将递归解压并分析其中的所有 Class。
	 *
	 * @return 找到并分析完成的类文件数量
	 */
	public int analyzeAll(final InputStream input, final String location)
			throws IOException {
		final ContentTypeDetector detector;
		try {
			detector = new ContentTypeDetector(input);
		} catch (final IOException e) {
			throw analyzerError(location, e);
		}
		switch (detector.getType()) {
		case ContentTypeDetector.CLASSFILE:
			analyzeClass(detector.getInputStream(), location);
			return 1;
		case ContentTypeDetector.ZIPFILE:
			return analyzeZip(detector.getInputStream(), location);
		case ContentTypeDetector.GZFILE:
			return analyzeGzip(detector.getInputStream(), location);
		case ContentTypeDetector.PACK200FILE:
			return analyzePack200(detector.getInputStream(), location);
		default:
			return 0;
		}
	}

	/**
	 * 分析指定的文件或文件夹。
	 * 如果传入的是文件夹，则会递归扫描并分析其中所有的 .class 和归档文件。
	 *
	 * @param file
	 *            待扫描分析的文件或目录
	 * @return 分析出的类文件总数
	 */
	public int analyzeAll(final File file) throws IOException {
		int count = 0;
		if (file.isDirectory()) {
			for (final File f : file.listFiles()) {
				count += analyzeAll(f);
			}
		} else {
			final InputStream in = new FileInputStream(file);
			try {
				count += analyzeAll(in, file.getPath());
			} finally {
				in.close();
			}
		}
		return count;
	}

	/**
	 * 从给定的 Classpath 列表中分析所有类。
	 * Classpath 内包含的各个绝对/相对路径以系统的 PathSeparator 隔开。
	 *
	 * @param path
	 *            Classpath 定义字符串
	 * @param basedir
	 *            基准目录，若为 null 则使用工作区目录作为相对路径基准
	 * @return 扫描到的类文件总数
	 */
	public int analyzeAll(final String path, final File basedir)
			throws IOException {
		int count = 0;
		final StringTokenizer st = new StringTokenizer(path,
				File.pathSeparator);
		while (st.hasMoreTokens()) {
			count += analyzeAll(new File(basedir, st.nextToken()));
		}
		return count;
	}

	private int analyzeZip(final InputStream input, final String location)
			throws IOException {
		final ZipInputStream zip = new ZipInputStream(input);
		ZipEntry entry;
		int count = 0;
		while ((entry = nextEntry(zip, location)) != null) {
			count += analyzeAll(zip, location + "@" + entry.getName());
		}
		return count;
	}

	private ZipEntry nextEntry(final ZipInputStream input,
			final String location) throws IOException {
		try {
			return input.getNextEntry();
		} catch (final IOException e) {
			throw analyzerError(location, e);
		} catch (final IllegalArgumentException e) {
			// 兼容某些 JDK 版本的 bug
			throw analyzerError(location, e);
		}
	}

	private int analyzeGzip(final InputStream input, final String location)
			throws IOException {
		GZIPInputStream gzipInputStream;
		try {
			gzipInputStream = new GZIPInputStream(input);
		} catch (final IOException e) {
			throw analyzerError(location, e);
		}
		return analyzeAll(gzipInputStream, location);
	}

	private int analyzePack200(final InputStream input, final String location)
			throws IOException {
		InputStream unpackedInput;
		try {
			unpackedInput = Pack200Streams.unpack(input);
		} catch (final IOException e) {
			throw analyzerError(location, e);
		}
		return analyzeAll(unpackedInput, location);
	}

}
