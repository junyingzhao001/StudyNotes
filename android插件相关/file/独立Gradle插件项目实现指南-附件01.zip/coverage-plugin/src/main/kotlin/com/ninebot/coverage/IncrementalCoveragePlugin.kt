package com.ninebot.coverage

import com.android.build.api.artifact.ScopedArtifact
import com.android.build.api.variant.AndroidComponentsExtension
import com.android.build.api.variant.ScopedArtifacts
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.provider.ListProperty
import org.gradle.api.provider.Property

/**
 * 插件配置扩展。
 * 用户可在 build.gradle.kts 中通过 coverageConfig { ... } 闭包自定义插件参数。
 */
abstract class CoverageExtension {
    /** 对比的基线分支名称，默认为 develop */
    abstract val baseBranch: Property<String>

    /** 允许插桩的业务包名前缀，支持点分包名或 class entry 路径 */
    abstract val includePackages: ListProperty<String>

    init {
        baseBranch.convention("develop")
        includePackages.convention(listOf())
    }
}

/**
 * 增量覆盖率 Gradle 插件。
 *
 * 核心设计思想：
 * 通过与开发分支（通常是 develop）进行 git diff 对比，自动圈定本次修改的代码范围。
 * 接着在编译期仅对这些被改动的方法进行字节码插桩（Offline Instrumentation），在运行时生成局部覆盖率数据。
 * 最后在报告生成阶段，通过行号重映射（SMAP）修复 Kotlin 内联函数的覆盖率归因，最终渲染生成精简且聚焦的 HTML 报告。
 *
 * 在 app 模块的 build.gradle 中通过 `apply plugin: com.ninebot.coverage.IncrementalCoveragePlugin` 启用。
 * 仅对 debug 构建变体（debug variant）生效，以保证 release 版本的字节码不被插桩污染。
 *
 * 插件注册并协调三个核心任务的生命周期：
 *   1. analyzeIncrementalChanges   — 分析 git 差异，输出变更的方法列表与类列表 JSON。
 *   2. {variant}InstrumentCoverage — 拦截编译产物，对属于增量范围的业务方法植入 JaCoCo 探针。
 *   3. {variant}GenerateCoverageReport — 结合运行时的覆盖率数据（.ec），分析变更类并生成最终的 HTML 报告。
 */
class IncrementalCoveragePlugin : Plugin<Project> {
    override fun apply(project: Project) {
        println(">>> Applying IncrementalCoveragePlugin")

        // 第一步：全局注册“变更分析任务”。
        // 该任务是整个增量流程的源头，在真正插桩前执行，负责产出：
        //   1. changed_methods.json：方法级变更范围，由 CoverageFilter 读取以指导插桩
        //   2. changed_classes.json：类级变更范围，由 GenerateCoverageReportTask 读取以限制报告生成范围
        val extension = project.extensions.create("coverageConfig", CoverageExtension::class.java)

        val analyzeTask = project.tasks.register("analyzeIncrementalChanges", AnalyzeIncrementalChangesTask::class.java)
        analyzeTask.configure {
            // 配置任务的输出路径，定位在构建目录 outputs/coverage/ 下
            outputFile = project.file("${project.buildDir}/outputs/coverage/changed_methods.json")
            // 将 Extension 中的基线分支配置绑定到任务
            targetBranch.set(extension.baseBranch)
        }

        // 获取 Android 编译组件扩展（AGP 8.x 的新 API），用以在编译周期的各种变体（variant）上进行回调和拦截
        val androidComponents = project.extensions.findByType(AndroidComponentsExtension::class.java)
        androidComponents?.onVariants(androidComponents.selector().withBuildType("debug")) { variant ->
            // 仅选择 buildType = debug 的变体注册插桩和报告任务。
            // 这样 assembleRelease / bundleRelease 等 release 构建不会接入 ScopedArtifacts 转换链，
            // release 包的字节码也就不会被 JaCoCo 离线插桩污染。

            // 第二步：注册“字节码插桩任务”。
            // 这个任务用于拦截当前 variant 编译出来的 class 与 jar，
            // 扫描符合条件的类进行 JaCoCo 字节码重写，并输出包含插桩后字节码的新 JAR 供下一阶段消费。
            val instrumentTask = project.tasks.register("${variant.name}InstrumentCoverage", InstrumentCoverageTask::class.java)
            instrumentTask.configure {
                // 声明强依赖关系：插桩任务执行前必须保证 git diff 变更分析已经完成，
                // 这样插桩器底层的 CoverageFilter 才能读取到最新生成的 changed_methods.json 增量配置。
                dependsOn(analyzeTask)
                includePackages.set(extension.includePackages)
            }

            // 第三步：注册“覆盖率报告生成任务”。
            // 该任务读取设备或模拟器上运行后导出的 coverage.ec 执行数据，结合变更的类列表生成直观的 HTML 报告。
            val reportTask = project.tasks.register("${variant.name}GenerateCoverageReport", GenerateCoverageReportTask::class.java)
            reportTask.configure {
                includePackages.set(extension.includePackages)
                // 指定运行时覆盖率数据输入文件，默认位于项目根目录的 coverage.ec
                ecFile.set(project.file("coverage.ec"))
                // 配置 HTML 报告的输出路径，区分不同的变体
                reportDir.set(project.file("${project.buildDir}/reports/coverage/${variant.name}"))

                // 报告渲染需要两类关键的输入数据：
                //   1. 源码目录（sourceDirs）：用于在 HTML 网页中展示源码详情并提供语法着色高亮。
                //   2. 编译后的 Class 目录（classDirs）：用于 JaCoCo 分析探针与行号的对应关系。
                //
                // 这里我们将当前 Project 及其所有子模块（subprojects）的源码和 Class 产物全部聚合进来，
                // 从而使得增量覆盖率报告能够完整支持跨多模块的工程项目分析。
                project.rootProject.subprojects.forEach { sub ->
                    sourceDirs.from(sub.file("src/main/java"), sub.file("src/main/kotlin"))
                    
                    // 编译后 class 文件的绝对目录：
                    //   - 对于 Kotlin 代码，其编译产物通常位于 build/tmp/kotlin-classes/
                    //   - 对于 Java 代码，其编译产物通常位于 build/intermediates/javac/
                    // 使用通配符包含其下的所有 .class 文件，以最大化兼容不同的 AGP 变体和构建设置。
                    classDirs.from(
                        sub.fileTree("${sub.buildDir}/tmp/kotlin-classes") {
                            include("**/*.class")
                        },
                        sub.fileTree("${sub.buildDir}/intermediates/javac") {
                            include("**/*.class")
                        }
                    )
                }
            }

            // --- 字节码流水线拦截（Bytecode Pipeline Transformation） ---
            // 使用 AGP 8.x 推荐的 ScopedArtifacts API 拦截整个项目的编译字节码：
            //   - Scope.ALL：表示要拦截的是整个打包流中的所有字节码（包括子模块、第三方库等全局 class 资源）
            //   - InstrumentCoverageTask 内部会做双重过滤：
            //       1. 粗过滤：根据包名白名单（如 shouldInstrument），将不属于我们核心业务的第三方库直接透传。
            //       2. 细过滤：根据 CoverageFilter 精准过滤没有被 git 变动的方法。
            //
            // 该 use(instrumentTask).toTransform() 管道化操作做到了：
            // 输入为原生的编译 classes（以 inputJars 和 inputDirs 的形式传入任务），
            // 输出为插桩修改后的统一 classes.jar（由 outputJar 指向），
            // 使得后续的 DEX 编译、混淆（ProGuard/R8）以及打包流程无缝消费经过增量插桩后的新字节码。
            variant.artifacts.forScope(ScopedArtifacts.Scope.ALL)
                .use(instrumentTask)
                .toTransform(
                    ScopedArtifact.CLASSES,
                    InstrumentCoverageTask::inputJars,
                    InstrumentCoverageTask::inputDirs,
                    InstrumentCoverageTask::outputJar
                )
        }
    }
}
