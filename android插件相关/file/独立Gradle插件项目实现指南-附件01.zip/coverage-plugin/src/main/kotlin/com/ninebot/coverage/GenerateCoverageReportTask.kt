package com.ninebot.coverage

import org.gradle.api.DefaultTask
import org.gradle.api.file.ConfigurableFileCollection
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.ListProperty
import org.gradle.api.tasks.*
import org.jacoco.core.analysis.Analyzer
import org.jacoco.core.analysis.CoverageBuilder
import org.jacoco.core.tools.ExecFileLoader
import org.jacoco.report.DirectorySourceFileLocator
import org.jacoco.report.html.HTMLFormatter
import org.jacoco.report.FileMultiReportOutput
import java.io.File

/**
 * 增量覆盖率报告生成任务。
 *
 * 核心逻辑：
 * 1. 读取运行时环境导出的覆盖率数据文件 `coverage.ec`（包含所有探针命中的二进制数据）。
 * 2. 加载增量分析产出的 `changed_classes.json`，判定哪些类发生了修改。
 * 3. 过滤并扫描编译输出目录中的 `.class` 文件：
 *    - 只有属于增量改动的类（或者触发了 inline 降级模式下的所有类）才会被送入 JaCoCo 分析器。
 *    - 在将类的字节码送入 JaCoCo 分析之前，**必须对字节码进行行号重映射（SMAP Remapping）**。
 * 4. 行号重映射（SMAP）的作用：
 *    - Kotlin 编译器在生成内联函数（inline function）时，由于内联段被塞入了调用方（Caller）的代码中，
 *      编译器会为内联部分赋予一套超出源文件总行数的“虚拟虚拟行号”，并在字节码的 SMAP 属性中记录它们与真实源码行的对应关系。
 *    - 如果我们直接将原始字节码送给 JaCoCo 报告分析，JaCoCo 看到那些超出物理行数的行号会无法识别，从而导致内联代码的覆盖率无法正确映射回源文件。
 *    - 本任务通过 ASM 读取并改写 Class 字节码的 LineNumberTable，将 SMAP 中的虚拟行号实时恢复为真实的源码行号，再交给 JaCoCo 执行分析，彻底解决 Kotlin 内联行覆盖率丢失问题。
 *    - 另外，对于原始的 inline 函数体本身（其代码已被内联到各处，原始函数永不被直接调用），我们主动剥离其 LineNumberTable 行号信息，
 *      从而消除 JaCoCo 针对它产生的永远无法覆盖的“红探针/死探针”，使覆盖率分值更为真实准确。
 */
abstract class GenerateCoverageReportTask : DefaultTask() {

    // 运行时生成的覆盖率执行数据，来自设备导出或拉取的 coverage.ec 文件
    @get:InputFile
    abstract val ecFile: RegularFileProperty

    // 编译后的类文件目录集合（包括各模块生成的 classes）
    @get:InputFiles
    abstract val classDirs: ConfigurableFileCollection

    // 工程的源码目录集合（用于 HTML 报告进行高亮展示）
    @get:InputFiles
    abstract val sourceDirs: ConfigurableFileCollection

    // 最终生成的 HTML 覆盖率报告目录
    @get:OutputDirectory
    abstract val reportDir: DirectoryProperty

    @get:Input
    abstract val includePackages: ListProperty<String>

    @TaskAction
    fun generate() {
        val ec = ecFile.get().asFile
        if (!ec.exists()) {
            println("No coverage data found at ${ec.absolutePath}")
            return
        }

        // 将最终的方法变更 JSON 路径存入 JVM 系统属性中。
        // 这使得底层的 CoverageFilter（它是由 JaCoCo 的 ClassProbesAdapter 静态调用的）能够读取并匹配到。
        val jsonFile = File(project.buildDir, "outputs/coverage/changed_methods.json")
        System.setProperty("jacoco.incremental.json", jsonFile.absolutePath)

        // 1. 加载二进制的覆盖率执行数据（Execution Data）
        val execFileLoader = ExecFileLoader()
        execFileLoader.load(ec)

        // 2. 加载增量变更类列表以控制报告的分析范围
        val classesFile = File(project.buildDir, "outputs/coverage/changed_classes.json")
        val changedClasses = mutableSetOf<String>()
        var hasInlineFallback = false
        
        if (classesFile.exists()) {
            val content = classesFile.readText()
            // 如果检查到 inline 变动标识，则报告阶段同样启用全量降级，以确保 SMAP 能够跨类完全解析正确
            if (content.contains("\"has_inline\": true") || content.contains("\"has_inline\":true")) {
                hasInlineFallback = true
                println("Fallback mode activated: inline functions modified, analyzing all classes for accurate SMAP resolution.")
            }
            
            // 简单的 JSON 正则解析，拉取 classes 数组中的所有类名
            val regex = Regex("\"([^\"]+)\"")
            regex.findAll(content).forEach { match ->
                val value = match.groupValues[1]
                if (value != "classes" && value != "has_inline") { // 过滤掉 JSON keys
                    changedClasses.add(value)
                }
            }
        }
        println("Report scope: ${changedClasses.size} changed classes: $changedClasses")

        // 3. 开始执行 JaCoCo 的分析过程
        val coverageBuilder = CoverageBuilder()
        // 使用底层的自定义 Analyzer。这里的 Analyzer 类是由我们 buildSrc 重写的 JaCoCo 源码，
        // 其内部的 ClassProbesAdapter 会配合 CoverageFilter 精准拦截没有变更的方法探针。
        val analyzer = Analyzer(execFileLoader.executionDataStore, coverageBuilder)

        if (changedClasses.isEmpty() && !hasInlineFallback) {
            println("No changed classes found, report will be empty.")
        } else {
            var analyzedCount = 0
            classDirs.forEach { dir ->
                if (dir.exists()) {
                    dir.walkTopDown()
                        .filter { it.isFile && it.name.endsWith(".class") }
                        .forEach { classFile ->
                            val classEntryName = toClassEntryName(classFile)
                            if (!shouldIncludeInReport(classEntryName)) {
                                return@forEach
                            }

                            val classFileClassName = classFile.nameWithoutExtension
                            // 处理嵌套类、匿名内部类（形如 MainActivity$MyListener）的匹配逻辑。
                            // 我们需要拿到它最外层的顶级类名，如果顶级类在增量范围中，其内部的所有嵌套类都应一起参与分析。
                            val topLevelClassName = classFileClassName.substringBefore("$")
                            if (hasInlineFallback ||
                                changedClasses.contains(classFileClassName) ||
                                changedClasses.contains(topLevelClassName)
                            ) {
                                try {
                                    val rawBytes = classFile.readBytes()
                                    // 【核心重映射】：读取 Class 文件的原始字节码，进行 SMAP 反向行号修正以及原始内联函数体行号剥离。
                                    // 这一步对于报告阶段至关重要，能让内联行号完美高亮归因，且生成的 ClassID 维持与插桩阶段的一致性。
                                    val remappedBytes = remapClassLines(rawBytes)
                                    java.io.ByteArrayInputStream(remappedBytes).use { input ->
                                        analyzer.analyzeAll(input, classFile.path)
                                        analyzedCount++
                                    }
                                } catch (e: Exception) {
                                    // 遇到损坏或不可读的非标准 class 文件直接跳过，保证任务鲁棒性
                                }
                            }
                        }
                }
            }
            println("Analyzed $analyzedCount class files")
        }

        // 4. 利用 HTMLFormatter 渲染并输出高品质的 HTML 报告
        val formatter = HTMLFormatter()
        val output = FileMultiReportOutput(reportDir.get().asFile)
        val visitor = formatter.createVisitor(output)

        // 写入会话信息和运行探针集
        visitor.visitInfo(
            execFileLoader.sessionInfoStore.infos,
            execFileLoader.executionDataStore.contents
        )

        // 提取已生成的所有覆盖率数据的 Bundle
        val bundle = coverageBuilder.getBundle("Incremental Coverage Report")

        // 配置多路径源码定位器。
        // JaCoCo 在生成 HTML 网页时，需要用它在磁盘上寻找对应的源代码文本来实现代码高亮展示。
        val locator = org.jacoco.report.MultiSourceFileLocator(4)
        sourceDirs.forEach { dir ->
            if (dir.exists()) {
                locator.add(DirectorySourceFileLocator(dir, "utf-8", 4))
            }
        }

        // 将覆盖率数据 Bundle 与源码定位器一起提交给 visitor 渲染
        visitor.visitBundle(bundle, locator)
        visitor.visitEnd()

        println("Incremental coverage report generated at: file://${reportDir.get().asFile.absolutePath}/index.html")
    }

    private fun shouldIncludeInReport(name: String): Boolean {
        if (!name.endsWith(".class")) return false
        if (name.endsWith("/R.class") || name.contains("/R$") || name.endsWith("/BuildConfig.class")) return false
        if (name.startsWith("com/ninebot/coverage/")) return false

        val excludedPrefixes = listOf(
            "android/",
            "androidx/",
            "com/google/",
            "com/android/",
            "kotlin/",
            "kotlinx/",
            "java/",
            "javax/",
            "org/",
            "okhttp3/",
            "okio/",
            "retrofit2/"
        )
        if (excludedPrefixes.any { name.startsWith(it) }) return false

        return includePackages.get()
            .map { it.trim().replace('.', '/').trim('/') }
            .filter { it.isNotEmpty() }
            .any { name.startsWith("$it/") }
    }

    private fun toClassEntryName(classFile: File): String {
        val normalizedPath = classFile.path.replace(File.separatorChar, '/')
        val includePrefixes = includePackages.get()
            .map { it.trim().replace('.', '/').trim('/') }
            .filter { it.isNotEmpty() }
            .sortedByDescending { it.length }

        includePrefixes.forEach { prefix ->
            val marker = "/$prefix/"
            val index = normalizedPath.indexOf(marker)
            if (index >= 0) {
                return normalizedPath.substring(index + 1)
            }
        }

        return classFile.name
    }

    // ==================== SMAP (JSR-045) 反向行号映射解析 ====================

    /**
     * 解析 Class 字节码 SourceDebugExtension 中的 SMAP 字符串，构建虚拟行号与真实源码行号的反向映射。
     *
     * 规范：JSR-045 规定了 SMAP 的语法。
     * 在行映射段 `*L` 之后，包含形如：
     *   `InputStartLine#FileId,RepeatCount:OutputStartLine,OutputLineIncrement`
     * 的映射单元。例如 `"60#1,4:78"` 代表源码的第 60..63 行在内联编译后，被映射到了虚拟行号的 78..81 行。
     *
     * 本方法会对该配置进行反向映射：即把输出虚拟行 78->60、79->61 建立联系，存入映射表。
     *
     * @return Map<虚拟输出行号, 真实物理源码行号>。为了节省资源，这里仅保留非恒等的虚拟行号映射。
     */
    private fun parseSmapLineMapping(smapString: String): Map<Int, Int> {
        val mapping = mutableMapOf<Int, Int>()
        val lines = smapString.lines()
        var inLineSection = false

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed == "*L") {
                inLineSection = true
                continue
            }
            // 遇到其他段标识（如 *E），代表行号段结束
            if (trimmed.startsWith("*") && trimmed != "*L") {
                inLineSection = false
                continue
            }
            if (!inLineSection || trimmed.isEmpty()) continue

            // 正则匹配 SMAP 行映射规范
            val regex = Regex("""(\d+)#(\d+)(?:,(\d+))?:(\d+)(?:,(\d+))?""")
            val match = regex.find(trimmed) ?: continue

            val inputStart = match.groupValues[1].toInt()
            val repeatCount = if (match.groupValues[3].isNotEmpty()) match.groupValues[3].toInt() else 1
            val outputStart = match.groupValues[4].toInt()
            val outputIncrement = if (match.groupValues[5].isNotEmpty()) match.groupValues[5].toInt() else 1

            for (i in 0 until repeatCount) {
                val outputLine = outputStart + i * outputIncrement
                val sourceLine = inputStart + i
                // 只记录虚拟行号与真实物理行号不相同的条目
                if (outputLine != sourceLine) {
                    mapping[outputLine] = sourceLine
                }
            }
        }

        return mapping
    }

    // ==================== ASM 字节码 LineNumberTable 改写 ====================

    /**
     * 利用 ASM 框架修改 Class 字节码的 LineNumberTable。
     *
     * 主要执行两个关键性的字节码微操：
     * 1. 虚拟行号纠正：利用 `parseSmapLineMapping` 得到映射表，在 visitLineNumber 时，将 SMAP 的虚拟行号映射回真实的源码行号。
     * 2. 剥离原始 inline 方法体的行号：
     *    - 原始 inline 方法的代码段永远只是被复制到外部，其自身内部的字节码探针是不可达的（称为死探针/永远为红）。
     *    - 我们需要将其行号信息彻底从 LineNumberTable 中移除，使 JaCoCo 报告阶段跳过对原始内联体的行级评估，保证整体分值合理。
     *    - 识别方法：Kotlin 编译器会在 inline 方法的字节码的 LocalVariableTable 中，生成一个形如 `\$i\$f\$<methodName>` 的特殊的局部变量标志。
     *      我们可以通过第一遍遍历（First Pass）扫描局部变量表，如果变量名前缀是 `\$i\$f\$` 且后缀跟当前方法名完全一致，说明此方法是原始的 inline 方法体，需要记录下来在第二遍回写时过滤掉其行号。
     */
    private fun remapClassLines(classBytes: ByteArray): ByteArray {
        val reader = org.objectweb.asm.ClassReader(classBytes)

        // 第一遍扫描（First Pass）：读取 SMAP Debug 属性并搜集原始 inline 方法签名。
        var smapString: String? = null
        val inlineMethods = mutableSetOf<String>()

        reader.accept(object : org.objectweb.asm.ClassVisitor(org.objectweb.asm.Opcodes.ASM9) {
            override fun visitSource(source: String?, debug: String?) {
                // debug 字段内包含了完整的 SMAP SourceDebugExtension 信息
                smapString = debug
            }

            override fun visitMethod(
                access: Int, name: String, descriptor: String,
                signature: String?, exceptions: Array<out String>?
            ): org.objectweb.asm.MethodVisitor {
                val methodKey = "$name$descriptor"
                val methodName = name
                return object : org.objectweb.asm.MethodVisitor(org.objectweb.asm.Opcodes.ASM9) {
                    override fun visitLocalVariable(
                        varName: String, varDesc: String, varSig: String?,
                        start: org.objectweb.asm.Label, end: org.objectweb.asm.Label, index: Int
                    ) {
                        // 检索 Kotlin 内联局部变量标记
                        if (varName.startsWith("\$i\$f\$")) {
                            val inlineFuncName = varName.substring(5)
                            // 必须保证标识的内联名与当前正在访问的方法名完全一致，
                            // 防止将包含内联调用（Caller）的方法误判为内联主体（Callee）。
                            if (inlineFuncName == methodName) {
                                inlineMethods.add(methodKey)
                            }
                        }
                    }
                }
            }
        }, 0)

        // 解析 SMAP 映射表
        val lineMapping = if (smapString != null) parseSmapLineMapping(smapString!!) else emptyMap()
        
        // 如果该 Class 既没有需要重映射的行号，也没有任何原始的 inline 方法体，则直接透传原字节码，无需二次重构以节省性能。
        if (lineMapping.isEmpty() && inlineMethods.isEmpty()) return classBytes

        // 第二遍扫描并回写（Second Pass）：利用 ClassWriter 重写 LineNumberTable。
        val writer = org.objectweb.asm.ClassWriter(0)
        reader.accept(object : org.objectweb.asm.ClassVisitor(org.objectweb.asm.Opcodes.ASM9, writer) {
            override fun visitMethod(
                access: Int, name: String, descriptor: String,
                signature: String?, exceptions: Array<out String>?
            ): org.objectweb.asm.MethodVisitor {
                val mv = super.visitMethod(access, name, descriptor, signature, exceptions)
                val isOriginalInlineMethod = inlineMethods.contains("$name$descriptor")

                return object : org.objectweb.asm.MethodVisitor(org.objectweb.asm.Opcodes.ASM9, mv) {
                    override fun visitLineNumber(line: Int, start: org.objectweb.asm.Label) {
                        // 1. 如果此方法被判定为原始内联函数体，则拦截调用，拒绝写入其行号信息，达成剥离行号的目的。
                        if (isOriginalInlineMethod) {
                            return
                        }
                        // 2. 如果存在虚拟行映射，将其替换为真实的源码行号，否则直接写入原行号。
                        val remapped = lineMapping[line] ?: line
                        super.visitLineNumber(remapped, start)
                    }
                }
            }
        }, 0)

        return writer.toByteArray()
    }
}
