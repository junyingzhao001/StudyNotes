package com.ninebot.coverage

import com.github.javaparser.StaticJavaParser
import com.github.javaparser.ast.Node
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration
import com.github.javaparser.ast.body.ConstructorDeclaration
import com.github.javaparser.ast.body.EnumDeclaration
import com.github.javaparser.ast.body.FieldDeclaration
import com.github.javaparser.ast.body.InitializerDeclaration
import com.github.javaparser.ast.body.MethodDeclaration
import com.github.javaparser.ast.expr.ObjectCreationExpr
import com.github.javaparser.ast.visitor.VoidVisitorAdapter
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import java.io.File
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.Input
import org.gradle.api.provider.Property

/**
 * 增量变更分析任务。
 *
 * 核心逻辑：
 * 1. 对比当前工作区与 `develop` 分支（或指定的基线分支），提取所有发生变更的 Java 和 Kotlin 源代码文件。
 * 2. 区分文件状态：
 *    - 【新增文件】(git status = A)：视为整个文件都是新增的，提取该文件中定义的所有方法进行插桩。
 *    - 【修改文件】(git status = M)：运行 `git diff -U0` 提取改动的精准行号，然后利用 AST（语法树）解析器
 *      定位改动行落在哪些方法（或构造函数、初始化块、属性访问器）的行号范围内，仅对这些受影响的方法进行插桩。
 *    - 【删除文件】(git status = D)：忽略，不参与插桩与分析。
 * 3. 分析完成后，在构建目录输出两个核心的 JSON 数据文件：
 *    - `changed_methods.json`  → 方法级增量圈定结果，供 `InstrumentCoverageTask` 插桩过滤使用（通过 CoverageFilter 匹配）。
 *    - `changed_classes.json`  → 类级增量范围，由 `GenerateCoverageReportTask` 读取，限制最终生成的 HTML 覆盖率报告仅包含变动的类。
 *
 * 内联函数降级策略：
 * - Kotlin 的 `inline` 函数在编译时会被直接嵌入到所有调用处（Caller）。
 * - 如果在当前分支修改了 `inline` 函数，为了确保调用它的类中内联探针和行号重映射（SMAP）的一致性，
 *   系统会检测到 `inline` 修改并将 `hasInlineModification` 置为 true，触发全量模式回退（Fallback），以防止覆盖率分析出错。
 */
abstract class AnalyzeIncrementalChangesTask : DefaultTask() {

    @get:Input
    abstract val targetBranch: Property<String>


    // 声明任务的主输出文件（方法级变更数据），采用 @OutputFile 以便 Gradle 跟踪 Task 增量和缓存状态。
    @get:OutputFile
    var outputFile = File(project.buildDir, "outputs/coverage/changed_methods.json")

    // 用于记录本分支是否修改了任何带有 `inline` 关键字的 Kotlin 方法。
    private var hasInlineModification = false

    /**
     * 保存 Git Diff 的行号变动结果。
     * @param newLines 新文件中发生增加或修改的行号列表。
     * @param deletedOldLines 旧文件中发生被删除的行号列表（需要回到 git 历史版本中用旧 AST 匹配被删方法）。
     */
    private data class DiffLines(
        val newLines: List<Int>,
        val deletedOldLines: List<Int>
    )

    /**
     * 尝试更新远程引用，确保 origin 分支引用尽量接近最新状态。
     * 失败时不阻塞流程，后续会自动回退到本地可用分支。
     */
    private fun fetchOriginIfPossible() {
        try {
            val process = ProcessBuilder("git", "fetch", "origin")
                .directory(project.rootDir)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start()
            val exitCode = process.waitFor()
            if (exitCode != 0) {
                println("  [WARN] git fetch origin failed (exit=$exitCode), continue with local refs")
            }
        } catch (e: Exception) {
            println("  [WARN] git fetch origin failed: ${e.message}")
        }
    }

    /** 判断 Git 引用是否存在。 */
    private fun hasGitRef(ref: String): Boolean {
        return try {
            val process = ProcessBuilder("git", "rev-parse", "--verify", "--quiet", ref)
                .directory(project.rootDir)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start()
            process.waitFor() == 0
        } catch (_: Exception) {
            false
        }
    }

    /**
     * 将配置的基线分支解析为实际可用的 Git 引用：
     * 1) 未显式带 remote 前缀时优先 origin/<baseBranch>
     * 2) 不存在时回退到本地 <baseBranch>
     * 3) 都不存在时返回 origin/<baseBranch>（让后续命令显式失败并打印上下文）
     */
    private fun resolveBaseRef(baseBranch: String): String {
        val normalized = baseBranch.trim()
        if (normalized.isEmpty()) return normalized

        // 用户已经显式传入 refs/remotes/... 或 origin/... 时，直接使用。
        if (normalized.contains("/")) return normalized

        val remoteRef = "origin/$normalized"
        return when {
            hasGitRef(remoteRef) -> remoteRef
            hasGitRef(normalized) -> normalized
            else -> remoteRef
        }
    }

    // ==================== Git 命令行操作 ====================

    /**
     * 获取相对 baseBranch 变动的所有源代码文件及其对应的 Git 状态。
     *
     * @param baseBranch 对比的基线分支名，例如 "develop"
     * @return Map<文件路径, Git状态标识(M/A/D/R...)>
     */
    private fun getChangedFiles(baseBranch: String): Map<String, String> {
        // 执行 `git diff --name-status develop`
        // 这一步获取文件列表以及它是被修改（M）、新增（A）还是删除（D）。
        val process = ProcessBuilder("git", "diff", "--name-status", baseBranch)
            .directory(project.rootDir)
            .redirectError(ProcessBuilder.Redirect.INHERIT)
            .start()
        val output = process.inputStream.bufferedReader().readText()
//        git diff output: M	MowerConfigJson
//        M	app/.gitignore
//        M	app/build.gradle
//                M	app/src/main/java/com/segway/mower/AppProviderImpl.java
//                M	app/src/main/java/com/segway/mower/HomePageProviderImpl.java
//                M	app/src/main/java/com/segway/mower/MainActivity.java
//                M	app/src/main/java/com/segway/mower/SegwayApplication.java
//                M	build.gradle
        process.waitFor()
        val result = mutableMapOf<String, String>()
        output.lines().forEach { line ->
            if (line.isBlank()) return@forEach
            val parts = line.split("\t", limit = 2)
            if (parts.size == 2) {
                val status = parts[0].trim()
                val filePath = parts[1].trim()
                // 我们只关心业务的 Java / Kotlin 源代码文件，
                // 像布局 XML、切图资源、Gradle 配置文件等不需要进行方法级的覆盖率分析。
                if (filePath.endsWith(".java") || filePath.endsWith(".kt")) {
                    result[filePath] = status
                }
            }
        }
        return result
    }

    /**
     * 获取指定修改文件中，具体发生变动的行号列表（新旧文件行均记录）。
     *
     * 使用 `git diff -U0` 能够让我们去除改动行前后的上下文干扰行（Context Lines），
     * 仅仅提取出发生修改、添加或删除的精准行区间，确保后面 AST 匹配的极高精度。
     */
    private fun getChangedLines(baseBranch: String, files: List<String>): Map<String, DiffLines> {
        val result = mutableMapOf<String, DiffLines>()
        for (file in files) {
            // 执行 `git diff -U0 develop -- <file>`
            val process = ProcessBuilder("git", "diff", "-U0", baseBranch, "--", file)
                .directory(project.rootDir)
                .start()
            val diffOutput = process.inputStream.bufferedReader().readText()
            process.waitFor()

            val newLines = mutableListOf<Int>()
            val deletedOldLines = mutableListOf<Int>()
            
            // 匹配形如 "@@ -10,2 +20,3 @@" 的 diff 块头部信息
            // 格式释义：旧文件从第10行开始删除了2行，新文件在第20行开始新增/改动了3行
            val regex = Regex("""@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@""")
            diffOutput.lines().forEach { line ->
                val match = regex.find(line)
                if (match != null) {
                    // 解析形如 @@ -10,2 +20,3 @@ 的 hunk，
                    // 新增/修改行用新文件行号；纯删除行要回到旧文件 AST 里定位原方法。
                    val oldStartLine = match.groupValues[1].toInt()
                    val oldCount = if (match.groupValues[2].isNotEmpty()) match.groupValues[2].toInt() else 1
                    val newStartLine = match.groupValues[3].toInt()
                    val newCount = if (match.groupValues[4].isNotEmpty()) match.groupValues[4].toInt() else 1
                    
                    // 记录被删除的旧行范围
                    if (oldCount > 0) {
                        for (i in 0 until oldCount) {
                            deletedOldLines.add(oldStartLine + i)
                        }
                    }
                    // 记录新增或修改的新行范围
                    if (newCount > 0) {
                        for (i in 0 until newCount) {
                            newLines.add(newStartLine + i)
                        }
                    }
                }
            }
            if (newLines.isNotEmpty() || deletedOldLines.isNotEmpty()) {
                result[file] = DiffLines(newLines, deletedOldLines)
            }
        }
        return result
    }

    // ==================== AST 方法解析与匹配 ====================

    /**
     * 精准解析【被修改文件】(M 状态)中受 Diff 变动行影响的方法。
     *
     * 原理：
     * 利用 AST 分析器解析文件的整个语法树结构。对于每个方法（或构造器、初始化块），提取其在源码中的起始与结束行号。
     * 如果 Git 改动的行号落在了该方法的作用范围内，则说明这个方法被修改了，需要被圈定插桩。
     *
     * @param changedLines 修改文件及其对应的变动行号 DiffLines
     * @param baseBranch 基线分支名（用于提取被删除代码的旧版源文件）
     * @return 圈定出的变更方法签名列表（格式为 `ClassName:methodName`）
     */
    private fun parseModifiedMethods(changedLines: Map<String, DiffLines>, baseBranch: String): List<String> {
        val changedMethods = mutableListOf<String>()

        changedLines.forEach { (filePath, diffLines) ->
            if (filePath.endsWith(".java")) {
                // 如果是 Java 代码：
                // 1. 如果新代码有新增/修改行，解析新版 Java 文件的 AST 找寻受影响方法。
                if (diffLines.newLines.isNotEmpty()) {
                    parseJavaModifiedMethods(filePath, diffLines.newLines, changedMethods)
                }
                // 2. 如果发生了纯删除行，需去 git 历史中读取旧版 Java 文件解析，抓出到底删掉了哪个方法。
                if (diffLines.deletedOldLines.isNotEmpty()) {
                    parseJavaDeletedMethods(baseBranch, filePath, diffLines.deletedOldLines, changedMethods)
                }
            } else if (filePath.endsWith(".kt")) {
                // 如果是 Kotlin 代码：
                // 同理，分别处理新行和旧行，使用针对 Kotlin PSI 语法树的解析逻辑。
                if (diffLines.newLines.isNotEmpty()) {
                    parseKotlinModifiedMethods(filePath, diffLines.newLines, changedMethods)
                }
                if (diffLines.deletedOldLines.isNotEmpty()) {
                    parseKotlinDeletedMethods(baseBranch, filePath, diffLines.deletedOldLines, changedMethods)
                }
            }
        }

        return changedMethods
    }

    /**
     * 解析【新增文件】(A 状态)中的所有方法。
     *
     * 由于整个文件都是全新添加的，文件内的所有方法都是增量代码，因此我们需要解析整个文件，
     * 将其中定义的所有方法（包括类内部的方法、构造函数等）统统加入到插桩白名单中。
     */
    private fun parseNewFileMethods(filePaths: List<String>): List<String> {
        val methods = mutableListOf<String>()

        filePaths.forEach { filePath ->
            val file = File(project.rootDir, filePath)
            if (!file.exists()) return@forEach

            if (filePath.endsWith(".java")) {
                parseJavaAllMethods(filePath, methods)
            } else if (filePath.endsWith(".kt")) {
                parseKotlinAllMethods(filePath, methods)
            }
        }

        return methods
    }

    // ---- Java AST 解析 (使用 JavaParser 库) ----

    private fun parseJavaModifiedMethods(filePath: String, lines: List<Int>, out: MutableList<String>) {
        val file = File(project.rootDir, filePath)
        if (file.exists()) {
            parseJavaSourceWithAST(filePath, file.nameWithoutExtension, file.readText(), lines, out)
        }
    }

    private fun parseJavaAllMethods(filePath: String, out: MutableList<String>) {
        val file = File(project.rootDir, filePath)
        if (file.exists()) {
            parseJavaSourceWithAST(filePath, file.nameWithoutExtension, file.readText(), null, out)
        }
        println("  [NEW-Java] $filePath -> AST parsed methods")
    }

    private fun parseJavaDeletedMethods(baseBranch: String, filePath: String, lines: List<Int>, out: MutableList<String>) {
        // 从 git 中读出旧版 Java 文件源码
        val oldSource = readFileFromGit(baseBranch, filePath) ?: return
        val defaultClassName = File(filePath).nameWithoutExtension
        val before = out.size
        parseJavaSourceWithAST(filePath, defaultClassName, oldSource, lines, out)
        if (out.size > before) {
            println("  [DEL-Java] $filePath -> ${out.drop(before)}")
        }
    }

    /**
     * 利用 JavaParser 解析 Java 源码，识别受影响的类、内部类、匿名内部类和各方法节点。
     *
     * @param filePath 源文件相对路径
     * @param defaultClassName 文件对应的顶层类名（无后缀）
     * @param source 待解析的 Java 源代码文本
     * @param lines 受影响的行号列表。如果是 null，说明是新增文件，全量提取所有方法。
     * @param out 结果收集列表
     */
    private fun parseJavaSourceWithAST(
        filePath: String,
        defaultClassName: String,
        source: String,
        lines: List<Int>?,
        out: MutableList<String>
    ) {
        try {
            // 解析生成编译单元 (CompilationUnit) source 是java的原始文件
            val cu = StaticJavaParser.parse(source)

            // 使用 AST 访问者模式进行深度优先遍历
            cu.accept(object : VoidVisitorAdapter<MutableList<String>>() {
                // 用于跟踪嵌套类的类名，解决内部类命名拼接问题 (例如 Outer$Inner)
                private val classStack = mutableListOf<String>()
                // 跟踪匿名内部类的计数器，JVM 编译匿名内部类会赋予 1, 2, 3 等数字名
                private val anonymousClassCounters = mutableMapOf<String, Int>()

                override fun visit(n: ClassOrInterfaceDeclaration, arg: MutableList<String>) {
                    classStack.add(n.nameAsString)
                    super.visit(n, arg)
                    classStack.removeAt(classStack.size - 1)
                }

                override fun visit(n: EnumDeclaration, arg: MutableList<String>) {
                    classStack.add(n.nameAsString)
                    super.visit(n, arg)
                    classStack.removeAt(classStack.size - 1)
                }

                /**
                 * 拼接当前的 JVM 类名标识。
                 * 嵌套内部类会被拼接为 `Outer$Inner` 以严格匹配 JVM 字节码中的类名形式。
                 */
                private fun getJvmClassName(): String {
                    if (classStack.isEmpty()) {
                        return defaultClassName
                    }
                    return classStack.joinToString("$")
                }

                override fun visit(n: ObjectCreationExpr, arg: MutableList<String>) {
                    // 如果存在匿名内部类体（形如 `new Runnable() { ... }`）
                    if (n.anonymousClassBody.isPresent) {
                        val enclosingClassName = getJvmClassName()
                        // 针对所在的外部类，计算匿名类的序号
                        val anonymousIndex = anonymousClassCounters.getOrDefault(enclosingClassName, 0) + 1
                        anonymousClassCounters[enclosingClassName] = anonymousIndex
                        
                        // 将序号作为类名压入栈，用来匹配生成的匿名内部类 JVM 名（如 MainActivity$1）
                        classStack.add(anonymousIndex.toString())
                        super.visit(n, arg)
                        classStack.removeAt(classStack.size - 1)
                    } else {
                        super.visit(n, arg)
                    }
                }

                /**
                 * 判断当前的 AST 语法节点是否落在改动行号范围内。
                 */
                private fun isChanged(node: Node): Boolean {
                    // lines == null 代表这是全新增文件，无脑判定为发生变更
                    if (lines == null) return true
                    if (!node.range.isPresent) return false
                    
                    val begin = node.range.get().begin.line
                    val end = node.range.get().end.line
                    // 判断改动行中是否有任何一行落在了该 AST 节点的 [begin, end] 闭区间内
                    return lines.any { it in begin..end }
                }

                override fun visit(n: MethodDeclaration, arg: MutableList<String>) {
                    if (isChanged(n)) {
                        arg.add("${getJvmClassName()}:${n.nameAsString}")
                    }
                    super.visit(n, arg)
                }

                override fun visit(n: ConstructorDeclaration, arg: MutableList<String>) {
                    if (isChanged(n)) {
                        // 构造函数在 JVM 字节码中的方法名叫作 <init>
                        arg.add("${getJvmClassName()}:<init>")
                    }
                    super.visit(n, arg)
                }

                override fun visit(n: InitializerDeclaration, arg: MutableList<String>) {
                    if (isChanged(n)) {
                        // 静态初始化块（static {}）对应 <clinit>，普通初始化块（{}）对应 <init>
                        val methodName = if (n.isStatic) "<clinit>" else "<init>"
                        arg.add("${getJvmClassName()}:$methodName")
                    }
                    super.visit(n, arg)
                }

                override fun visit(n: FieldDeclaration, arg: MutableList<String>) {
                    if (isChanged(n)) {
                        // 成员变量声明如果有初始化赋值，最终会被编入静态初始化器或构造函数中，
                        // 因此我们把变动映射到相应的初始化器
                        val methodName = if (n.isStatic) "<clinit>" else "<init>"
                        arg.add("${getJvmClassName()}:$methodName")
                    }
                    super.visit(n, arg)
                }
            }, out)

        } catch (e: Exception) {
            println("  [WARN] Failed to parse Java file $filePath: ${e.message}")
        }
    }

    // ---- Kotlin AST 解析 ----

    private fun parseKotlinModifiedMethods(filePath: String, lines: List<Int>, out: MutableList<String>) {
        parseKotlinFileWithAST(filePath, lines, out)
    }

    private fun parseKotlinAllMethods(filePath: String, out: MutableList<String>) {
        parseKotlinFileWithAST(filePath, null, out)
        println("  [NEW-Kotlin] $filePath -> AST parsed methods")
    }

    private fun parseKotlinDeletedMethods(baseBranch: String, filePath: String, lines: List<Int>, out: MutableList<String>) {
        val oldSource = readFileFromGit(baseBranch, filePath) ?: return
        val before = out.size
        parseKotlinSourceWithAST(filePath, oldSource, lines, out)
        if (out.size > before) {
            println("  [DEL-Kotlin] $filePath -> ${out.drop(before)}")
        }
    }

    /**
     * 轻量扫描 Kotlin 源码，提取方法、构造器、init 块以及属性访问器。
     *
     * 这里避免在 Gradle 插件运行时引入 Kotlin compiler / IntelliJ PSI。那些依赖会和消费者工程的
     * Kotlin Gradle Plugin 共用 buildscript classpath，容易出现 `Document`、`CompilerConfigurationKey`
     * 等内部类版本冲突。
     */
    private fun parseKotlinFileWithAST(filePath: String, lines: List<Int>?, out: MutableList<String>) {
        val file = File(project.rootDir, filePath)
        if (!file.exists()) return

        parseKotlinSourceWithAST(filePath, file.readText(), lines, out)
    }

    private fun parseKotlinSourceWithAST(filePath: String, source: String, lines: List<Int>?, out: MutableList<String>) {
        val file = File(project.rootDir, filePath)
        val sourceLines = source.lines()
        val fileClassName = Regex("@file:JvmName\\(\\s*\"([^\"]+)\"\\s*\\)")
            .find(source)
            ?.groupValues
            ?.get(1)
            ?: (file.nameWithoutExtension + "Kt")

        val classStack = mutableListOf<Pair<String, Int>>()
        var pendingProperty: Pair<String, String>? = null

        fun currentClassName(): String =
            if (classStack.isEmpty()) fileClassName else classStack.joinToString("$") { it.first }

        fun isTargetLine(lineNumber: Int): Boolean = lines == null || lineNumber in lines

        fun accessorName(prefix: String, propertyName: String): String = when {
            prefix == "get" && propertyName.startsWith("is") && propertyName.length > 2 && propertyName[2].isUpperCase() -> propertyName
            prefix == "set" && propertyName.startsWith("is") && propertyName.length > 2 && propertyName[2].isUpperCase() -> "set" + propertyName.substring(2)
            else -> prefix + propertyName.replaceFirstChar { char -> if (char.isLowerCase()) char.titlecase() else char.toString() }
        }

        sourceLines.forEachIndexed { index, rawLine ->
            val lineNumber = index + 1
            val line = rawLine.substringBefore("//")
            val trimmed = line.trim()

            while (classStack.isNotEmpty() && line.count { it == '}' } > line.count { it == '{' } && trimmed.startsWith("}")) {
                classStack.removeAt(classStack.size - 1)
            }

            Regex("\\b(?:class|object|interface|enum\\s+class)\\s+([A-Za-z_][A-Za-z0-9_]*)")
                .find(trimmed)
                ?.let { match -> classStack.add(match.groupValues[1] to lineNumber) }

            Regex("\\b(?:suspend\\s+|operator\\s+|infix\\s+|tailrec\\s+|external\\s+|public\\s+|private\\s+|protected\\s+|internal\\s+|override\\s+|open\\s+|final\\s+|abstract\\s+)*inline\\s+fun\\s+([A-Za-z_][A-Za-z0-9_]*)")
                .find(trimmed)
                ?.takeIf { isTargetLine(lineNumber) }
                ?.let {
                    hasInlineModification = true
                    println("  [Fallback] Detected modified inline function: ${it.groupValues[1]}")
                }

            Regex("\\bfun\\s+(?:<[^>]+>\\s*)?(?:[A-Za-z_][A-Za-z0-9_]*\\.)?([A-Za-z_][A-Za-z0-9_]*)\\s*\\(")
                .find(trimmed)
                ?.takeIf { isTargetLine(lineNumber) }
                ?.let { out.add("${currentClassName()}:${it.groupValues[1]}") }

            if (Regex("\\bconstructor\\s*\\(").containsMatchIn(trimmed) && isTargetLine(lineNumber)) {
                out.add("${currentClassName()}:<init>")
            }
            if (Regex("\\binit\\s*\\{").containsMatchIn(trimmed) && isTargetLine(lineNumber)) {
                out.add("${currentClassName()}:<init>")
            }

            Regex("\\b(?:val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)")
                .find(trimmed)
                ?.let { match ->
                    val propertyName = match.groupValues[1]
                    val className = currentClassName()
                    pendingProperty = propertyName to className
                    if (isTargetLine(lineNumber) && (trimmed.contains("=") || trimmed.contains(" by "))) {
                        out.add("$className:<init>")
                    }
                }

            pendingProperty?.let { (propertyName, className) ->
                if (trimmed.startsWith("get()") && isTargetLine(lineNumber)) {
                    out.add("$className:${accessorName("get", propertyName)}")
                }
                if (trimmed.startsWith("set(") && isTargetLine(lineNumber)) {
                    out.add("$className:${accessorName("set", propertyName)}")
                }
                if (trimmed.isNotEmpty() && !trimmed.startsWith("get()") && !trimmed.startsWith("set(") && !trimmed.startsWith("@")) {
                    pendingProperty = null
                }
            }
        }
    }

    /**
     * 通过执行 `git show <commit_or_branch>:<file>` 命令读取文件在历史基线版本中的旧内容。
     * 这使得我们能够在不污染当前工作区文件的前提下，对已经被彻底删除的方法定位其原始名。
     */
    private fun readFileFromGit(baseBranch: String, filePath: String): String? {
        return try {
            val process = ProcessBuilder("git", "show", "$baseBranch:$filePath")
                .directory(project.rootDir)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            if (process.waitFor() == 0) output else null
        } catch (e: Exception) {
            println("  [WARN] Failed to read $filePath from $baseBranch: ${e.message}")
            null
        }
    }

    // ==================== 任务主执行入口 ====================

    @TaskAction
    fun analyze() {
        val configuredBaseBranch = targetBranch.get()
        fetchOriginIfPossible()
        val baseBranch = resolveBaseRef(configuredBaseBranch)

        println("========== Incremental Coverage Analysis ==========")
        println("Configured base branch: $configuredBaseBranch")
        println("Resolved base ref: $baseBranch (including working tree changes)")

        println("对比分支: $baseBranch")

        // 1. 获取发生变更的所有源代码文件及其对应的 git 状态
        val changedFilesWithStatus = getChangedFiles(baseBranch)
        println("Total changed source files: ${changedFilesWithStatus.size}")
        changedFilesWithStatus.forEach { (file, status) ->
            println("  [$status] $file")
        }

        // 2. 将文件状态分类为新增文件 (A) 与修改文件 (M)
        val newFiles = changedFilesWithStatus.filter { it.value.startsWith("A") }.keys.toList()
        val modifiedFiles = changedFilesWithStatus.filter { it.value.startsWith("M") }.keys.toList()
        println("New files (A): ${newFiles.size}, Modified files (M): ${modifiedFiles.size}")

        // 3. 对【修改文件】，只提取发生行号变更的方法列表
        val changedLinesByFile = getChangedLines(baseBranch, modifiedFiles)
        val modifiedMethods = parseModifiedMethods(changedLinesByFile, baseBranch)
        println("Modified methods from M files: $modifiedMethods")

        // 4. 对【新增文件】，无条件提取其定义的所有方法
        val newMethods = parseNewFileMethods(newFiles)
        println("New methods from A files: ${newMethods.size} methods")

        // 5. 合并并去重，获取最终发生修改的方法集和类集
        val allChangedMethods = (modifiedMethods + newMethods).distinct()
        val allChangedClasses = allChangedMethods.map { it.substringBefore(":") }.distinct()

        println("Final: ${allChangedMethods.size} methods in ${allChangedClasses.size} classes")

        // ---- 写入配置到 outputs/coverage/ 目录 ----
        outputFile.parentFile.mkdirs()

        // 生成 changed_methods.json。这个文件会在插桩阶段由 CoverageFilter 读取。
        // 它包含 has_inline 字段来告诉插桩器是否退回全量模式。
        val methodsJson = if (allChangedMethods.isEmpty()) {
            "{\n  \"has_inline\": $hasInlineModification,\n  \"methods\": []\n}"
        } else {
            val methodsStr = allChangedMethods.joinToString(separator = "\",\n    \"", prefix = "[\n    \"", postfix = "\"\n  ]")
            "{\n  \"has_inline\": $hasInlineModification,\n  \"methods\": $methodsStr\n}"
        }
        outputFile.writeText(methodsJson)

        // 生成 changed_classes.json。这个文件会在报告生成阶段由 GenerateCoverageReportTask 读取，
        // 限制 HTML 报告仅渲染发生过修改的类的页面。
        val classesFile = File(outputFile.parentFile, "changed_classes.json")
        val classesJson = if (allChangedClasses.isEmpty()) {
            "{\n  \"has_inline\": $hasInlineModification,\n  \"classes\": []\n}"
        } else {
            val classesStr = allChangedClasses.joinToString(separator = "\",\n    \"", prefix = "[\n    \"", postfix = "\"\n  ]")
            "{\n  \"has_inline\": $hasInlineModification,\n  \"classes\": $classesStr\n}"
        }
        classesFile.writeText(classesJson)

        println("Output: ${outputFile.absolutePath}")
        println("Output: ${classesFile.absolutePath}")
        println("========== Analysis Complete ==========")
    }
}
