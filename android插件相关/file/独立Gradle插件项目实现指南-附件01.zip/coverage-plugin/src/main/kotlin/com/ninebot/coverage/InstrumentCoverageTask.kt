package com.ninebot.coverage

import org.objectweb.asm.ClassReader
import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Label
import org.objectweb.asm.Opcodes
import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.ListProperty
import org.gradle.api.tasks.*
import org.jacoco.core.instr.Instrumenter
import org.jacoco.core.runtime.OfflineInstrumentationAccessGenerator
import java.io.File
import java.io.FileOutputStream
import java.util.jar.JarEntry
import java.util.jar.JarFile
import java.util.jar.JarOutputStream
import org.jacoco.core.internal.flow.CoverageFilter
import org.objectweb.asm.ClassWriter
import java.io.ByteArrayInputStream

/**
 * 字节码插桩任务。
 *
 * 核心逻辑与职责：
 * 1. 它是 AGP ScopedArtifacts 流水线拦截中的核心处理器，拦截当前模块和依赖的子模块中所有编译产出的 class 和 jar。
 * 2. 使用 JaCoCo 官方的 `Instrumenter` 在离线状态下对代码注入覆盖率计数探针（Offline Instrumentation）。
 * 3. 它将所有的类（无论是否被插桩）重新打包，合并输出到一个统一的 `outputJar` 中，流向下游的 DEX/混淆 任务。
 *
 * 增量与过滤设计：
 * - 粗过滤：基于包名白名单（通过 `shouldInstrument` 判断），剔除第三方依赖，防止不必要的字节码操作风险并缩短编译耗时。
 * - 精细匹配：属于白名单内的类会被送入插桩流程，在 Class 级别内层使用 `ClassProbesAdapter` 结合 `CoverageFilter`
 *   读取 `changed_methods.json` 来精细判断具体的某一个方法是否需要植入探针，没有被 Git 变动的方法会被直接忽略，不插桩任何探针。
 *
 * 关键点 — 【插桩与报告字节码的一致性】：
 * - JaCoCo 在插桩时和报告分析时，都会通过 CRC64 计算 Class 的唯一 ID。
 *   如果两者拿到的 Class 字节码不一致（哪怕只是行号表有一些微小变动），就会导致报告阶段抛出 "A different version of class was executed" 异常，
 *   或者抛出数组越界（ArrayIndexOutOfBoundsException），无法生成正常的覆盖率。
 * - 为了彻底解决这个问题，**我们在插桩阶段同样进行一遍 `remapClassLines`（SMAP 虚拟行号重映射以及 inline 方法行号剥离）**，
 *   确保送给 `instrumenter` 插桩的“基准字节码”与后面报告阶段使用的“基准字节码”在字节级完全一致。
 *   这也达成了探针数量与重映射后行号的完美对齐。
 */
abstract class InstrumentCoverageTask : DefaultTask() {

    // 输入的 JAR 包列表（包括子工程模块、依赖包等）
    @get:InputFiles
    abstract val inputJars: ListProperty<org.gradle.api.file.RegularFile>

    // 输入的文件目录列表（主要是当前工程编译出的 class 目录）
    @get:InputFiles
    abstract val inputDirs: ListProperty<org.gradle.api.file.Directory>

    // 唯一的输出 JAR，包含所有插桩后的和未被插桩原样拷贝的编译 Class
    @get:OutputFile
    abstract val outputJar: RegularFileProperty

    @get:Input
    abstract val includePackages: ListProperty<String>

    @TaskAction
    fun instrument() {
        // 创建 JaCoCo 离线插桩器。它会在类的静态初始化块中注入离线数据收集器的调用。
        val instrumenter = Instrumenter(OfflineInstrumentationAccessGenerator())

        val outJar = outputJar.get().asFile
        outJar.parentFile.mkdirs()

        // 用于去重。因为可能存在多个 class 目录或 jar 中包含相同的条目名（如 META-INF），
        // 必须通过 seenEntries 过滤已写入的文件，以避免产生 Duplicate Entry 的 ZipException 错误。
        val seenEntries = mutableSetOf<String>()

        // 配置变更方法 JSON 文件的绝对路径，注入到 JVM SystemProperty。
        // 这使得在 JaCoCo 的 ClassProbesAdapter 中被调用的 CoverageFilter 能够动态读取到正确的变更集。
        val jsonFile = File(project.buildDir, "outputs/coverage/changed_methods.json")
        System.setProperty("jacoco.incremental.json", jsonFile.absolutePath)
        
        // 【解决 Gradle 守护进程静态缓存问题】：
        // Gradle 守护进程（Daemon）在多次构建间保持存活。如果 CoverageFilter 中的 changedMethods
        // 是一个静态集合且没有清理机制，那么下一次运行 `gradle debugInstrumentCoverage` 时，它仍会消费上一次的变更集缓存。
        // 我们在每次插桩任务启动时，显式调用 CoverageFilter.resetCache()，强制其在接下来的插桩中重新读取最新的 JSON 文件。
        CoverageFilter.resetCache()

        JarOutputStream(FileOutputStream(outJar)).use { jos ->
            // ==================== 第一类输入：文件夹形式的 class 产物 ====================
            inputDirs.get().forEach { dir ->
                val root = dir.asFile
                if (root.exists()) {
                    root.walkTopDown().filter { it.isFile }.forEach { file ->
                        val entryName = file.relativeTo(root).path.replace(File.separatorChar, '/')
                        
                        // 重复条目去重拦截
                        if (!seenEntries.add(entryName)) {
                            return@forEach
                        }

                        jos.putNextEntry(JarEntry(entryName))
                        println("Instrumenting::::::::::: ${file.absolutePath}")
                        // 仅对以 .class 结尾且符合包名白名单的业务类文件执行增量插桩
                        if (file.name.endsWith(".class") && shouldInstrument(entryName)) {
                            val rawBytes = file.readBytes()
                            try {
                                // 1. 先对原始 Class 字节码做 SMAP 反向行号映射及内联体行号剥离
                                val remappedBytes = remapClassLines(rawBytes)
                                // 2. 再送入插桩器植入覆盖率探针。这样 class 探针的数量、索引都和重映射后的 LineNumberTable 完美匹配，ClassID 也能和报告阶段严丝合缝
                                val instrumented = instrumenter.instrument(
                                    ByteArrayInputStream(remappedBytes), entryName
                                )
                                jos.write(instrumented)
                            } catch (e: Exception) {
                                // 如果万一由于特殊的类格式导致重写或插桩失败，降级写入原始字节码，防止直接中断编译过程
                                jos.write(rawBytes)
                            }
                        } else {
                            // 非 class 资源文件、包名之外的类一律不作处理，直接写入输出流
                            jos.write(file.readBytes())
                        }
                        jos.closeEntry()
                    }
                }
            }

            // ==================== 第二类输入：JAR 包形式的 class 产物 ====================
            inputJars.get().forEach { regularFile ->
                val jarFile = regularFile.asFile
                if (jarFile.exists()) {
                    JarFile(jarFile).use { jar ->
                        jar.entries().asSequence().forEach { entry ->
                            // 过滤掉目录项以及重复的条目
                            if (entry.isDirectory || !seenEntries.add(entry.name)) {
                                return@forEach
                            }
                            jos.putNextEntry(JarEntry(entry.name))
                            jar.getInputStream(entry).use { input ->
                                println("Instrumenting1::::::::::: ${entry.name}")
                                if (entry.name.endsWith(".class") && shouldInstrument(entry.name)) {
                                    val rawBytes = input.readBytes()
                                    try {
                                        // 与上面一致：先执行 SMAP 转换，再执行 JaCoCo 插桩
                                        val remappedBytes = remapClassLines(rawBytes)
                                        val instrumented = instrumenter.instrument(
                                            ByteArrayInputStream(remappedBytes), entry.name
                                        )
                                        jos.write(instrumented)
                                    } catch (e: Exception) {
                                        jos.write(rawBytes)
                                    }
                                } else {
                                    // 遇到不参与分析的类或资源包，通过高效的文件通道直接复制，保证性能
                                    input.copyTo(jos)
                                }
                            }
                            jos.closeEntry()
                        }
                    }
                }
            }
        }
    }

    /**
     * 包名粗筛白名单：只针对我们自己业务域内的类进行 JaCoCo 覆盖率分析。
     *
     * 作用：
     * 1. 节省数以万计的第三方依赖类（如 com/google, androidx, okhttp 等）的插桩编译耗时。
     * 2. 防止对库进行不必要的插桩引起 runtime 异常或包体积暴涨。
     */
    private fun shouldInstrument(name: String): Boolean {
        if (!name.endsWith(".class")) return false
        if (name.endsWith("/R.class") || name.contains("/R$") || name.endsWith("/BuildConfig.class")) return false

        val excludedPrefixes = listOf(
            "android/",
            "androidx/",
            "com/google/",
            "com/android/",
            "kotlin/",
            "kotlinx/",
            "java/",
            "javax/",
            "org/",
            "okhttp3/",
            "okio/",
            "retrofit2/"
        )
        if (excludedPrefixes.any { name.startsWith(it) }) return false

        includePackages.get().forEach {
            println("白名单：$it")
        }

        return includePackages.get()
            .map { it.trim().replace('.', '/').trim('/') }
            .filter { it.isNotEmpty() }
            .any { name.startsWith("$it/") }
    }

    // ==================== SMAP (JSR-045) 行号映射解析 ====================

    /**
     * 解析 SMAP Debug 文本，构建反向映射关系表：输出虚拟行号 -> 真实源码行号。
     * 同样只保存非恒等（虚拟行号不等于真实行号）的数据映射项。
     */
    private fun parseSmapLineMapping(smapString: String): Map<Int, Int> {
        val mapping = mutableMapOf<Int, Int>()
        val lines = smapString.lines()
        var inLineSection = false

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed == "*L") {
                inLineSection = true
                continue
            }
            if (trimmed.startsWith("*") && trimmed != "*L") {
                inLineSection = false
                continue
            }
            if (!inLineSection || trimmed.isEmpty()) continue

            val regex = Regex("""(\d+)#(\d+)(?:,(\d+))?:(\d+)(?:,(\d+))?""")
            val match = regex.find(trimmed) ?: continue

            val inputStart = match.groupValues[1].toInt()
            val repeatCount = if (match.groupValues[3].isNotEmpty()) match.groupValues[3].toInt() else 1
            val outputStart = match.groupValues[4].toInt()
            val outputIncrement = if (match.groupValues[5].isNotEmpty()) match.groupValues[5].toInt() else 1

            for (i in 0 until repeatCount) {
                val outputLine = outputStart + i * outputIncrement
                val sourceLine = inputStart + i
                if (outputLine != sourceLine) {
                    mapping[outputLine] = sourceLine
                }
            }
        }
        return mapping
    }

    // ==================== ASM 字节码操作（重写 LineNumberTable） ====================

    /**
     * 字节码级行号调整与 inline 死探针行号移除。
     *
     * 细节实现：
     * 1. 第一遍扫描（ClassVisitor）：从 visitSource 捕获 SMAP 内容，并检查各方法体中 LocalVariableTable 局部变量表。
     *    如果存在 `$i$f$<functionName>` 局部变量，且与当前访问的方法名一致，则圈定为原始内联函数主体方法。
     * 2. 第二遍回写（ClassWriter）：
     *    - 将虚拟行号利用 SMAP 映射关系转化回真实的物理源文件行号。
     *    - 抛弃已被确立为原始内联函数的方法体内部的所有 `visitLineNumber` 写入，彻底消除永远为红的死探针，提升覆盖率真实性。
     */
    private fun remapClassLines(classBytes: ByteArray): ByteArray {
        val reader = ClassReader(classBytes)

        var smapString: String? = null
        val inlineMethods = mutableSetOf<String>()

        reader.accept(object : ClassVisitor(Opcodes.ASM9) {
            override fun visitSource(source: String?, debug: String?) {
                smapString = debug
            }

            override fun visitMethod(
                access: Int, name: String, descriptor: String,
                signature: String?, exceptions: Array<out String>?
            ): MethodVisitor {
                val methodKey = "$name$descriptor"
                val methodName = name
                return object : MethodVisitor(Opcodes.ASM9) {
                    override fun visitLocalVariable(
                        varName: String, varDesc: String, varSig: String?,
                        start: Label, end: Label, index: Int
                    ) {
                        // 匹配 Kotlin 编译内联方法标志
                        if (varName.startsWith("\$i\$f\$")) {
                            val inlineFuncName = varName.substring(5)
                            if (inlineFuncName == methodName) {
                                inlineMethods.add(methodKey)
                            }
                        }
                    }
                }
            }
        }, 0)

        val lineMapping = if (smapString != null) parseSmapLineMapping(smapString!!) else emptyMap()

        if (lineMapping.isEmpty() && inlineMethods.isEmpty()) return classBytes

        val writer = ClassWriter(0)
        reader.accept(object : ClassVisitor(Opcodes.ASM9, writer) {
            override fun visitMethod(
                access: Int, name: String, descriptor: String,
                signature: String?, exceptions: Array<out String>?
            ): MethodVisitor {
                val mv = super.visitMethod(access, name, descriptor, signature, exceptions)
                val isOriginalInlineMethod = inlineMethods.contains("$name$descriptor")

                return object : MethodVisitor(Opcodes.ASM9, mv) {
                    override fun visitLineNumber(line: Int, start: Label) {
                        if (isOriginalInlineMethod) {
                            // 丢弃原始 inline 函数体的行号，避免对它们进行行级覆盖分析
                            return
                        }
                        val remapped = lineMapping[line] ?: line
                        super.visitLineNumber(remapped, start)
                    }
                }
            }
        }, 0)

        return writer.toByteArray()
    }
}
